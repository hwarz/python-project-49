#!/usr/bin/env python

from brain_games.games.even import even_gm


def main():
    even_gm()


if __name__ == '__main__':
    main()
