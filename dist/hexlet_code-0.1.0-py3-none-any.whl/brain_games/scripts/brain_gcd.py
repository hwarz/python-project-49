#!/usr/bin/env python

from brain_games.games.gcd import gcd_gm


def main():
    gcd_gm()


if __name__ == '__main__':
    main()
