#!/usr/bin/env python

from brain_games.games.prime import prime_gm


def main():
    prime_gm()


if __name__ == '__main__':
    main()
