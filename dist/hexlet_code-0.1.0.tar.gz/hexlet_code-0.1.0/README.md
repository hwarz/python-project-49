### Hexlet tests and linter status:
[![Actions Status](https://github.com/hwarz/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/hwarz/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/8136a514e6c01bab3537/maintainability)](https://codeclimate.com/github/hwarz/python-project-49/maintainability)
