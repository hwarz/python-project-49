#!/usr/bin/env python

from brain_games.games.progression import progression_gm


def main():
    progression_gm()


if __name__ == '__main__':
    main()
